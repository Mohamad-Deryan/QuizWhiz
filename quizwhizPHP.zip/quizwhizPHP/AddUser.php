<?php
require_once 'connection.php';
$name = $_GET['name'];
$query = "insert into Users(name) values('$name')";
if(mysqli_query($con, $query)){
    echo "1";
}
else{
    echo "-1";
}
?>
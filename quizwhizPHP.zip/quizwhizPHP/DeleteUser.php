<?php
require_once 'connection.php';
$query = "DELETE FROM Users ORDER BY user_id DESC LIMIT 1";
if (mysqli_query($con, $query)) {
    echo "1";
} else {
    echo "-1";
}
?>
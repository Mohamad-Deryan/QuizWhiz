<?php
require_once 'connection.php';

if (isset($_GET['topic'])) {
    $topic = $_GET['topic'];

    $query = "SELECT a.answer 
              FROM Answers a 
              INNER JOIN Questions q ON a.question_id = q.question_id 
              WHERE q.topic = '$topic'";

    $result = mysqli_query($con, $query);

    if ($result) {
        $answers = array();

        while ($row = mysqli_fetch_assoc($result)) {
            $answers[] = $row['answer'];
        }

        echo json_encode($answers);
    } else {
        echo json_encode(array("error" => "Error."));
    }
} else {
    echo json_encode(array("error" => "Topic missing."));
}
?>
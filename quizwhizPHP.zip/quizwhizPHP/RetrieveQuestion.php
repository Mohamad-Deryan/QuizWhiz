<?php
require_once 'connection.php';
$topic = $_GET['topic'];
$query = "SELECT question_id, question FROM Questions WHERE topic = '$topic'";
$result = mysqli_query($con, $query);

$questions = array();
while ($row = mysqli_fetch_assoc($result)) {
    $questions[] = $row;
}
echo json_encode($questions);
?>
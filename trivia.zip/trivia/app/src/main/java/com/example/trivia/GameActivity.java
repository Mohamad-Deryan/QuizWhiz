package com.example.trivia;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class GameActivity extends AppCompatActivity {

    static int currentQuestionIndex = 0;
    List<String> questions = new ArrayList<>();
    List<String> answers = new ArrayList<>();
    int[] playerScores;
    CountDownTimer timer;
    EditText p1Answer;
    int numberOfPlayers;
    TextView questionTextView, scoreTextView, timerTextView, Winner;
    Button btn_submit, btnsubmit2;
    Button player1Button, player2Button, player3Button, player4Button;
    static int n;
    int singleScore = 0;
    String PlayerName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        questionTextView = findViewById(R.id.txt_question);
        scoreTextView = findViewById(R.id.txt_score);
        timerTextView = findViewById(R.id.txt_timer);
        btnsubmit2 = findViewById(R.id.btn_submit2);
        Winner = findViewById(R.id.Winner);
        p1Answer = findViewById(R.id.P1Answer);


        player1Button = findViewById(R.id.btn_player1_answer);
        player2Button = findViewById(R.id.btn_player2_answer);
        player3Button = findViewById(R.id.btn_player3_answer);
        player4Button = findViewById(R.id.btn_player4_answer);
        btn_submit = findViewById(R.id.btn_submit);

        Intent i = getIntent();
        String topic = i.getStringExtra("selectedTopic");
        numberOfPlayers = i.getIntExtra("selectedPlayers", 1);
        PlayerName = i.getStringExtra("PlayerName");

        if (numberOfPlayers==1){
            currentQuestionIndex=0;
            player1Button.setVisibility(View.INVISIBLE);
            player2Button.setVisibility(View.INVISIBLE);
            scoreTextView.setVisibility(View.INVISIBLE);
            fetchQuestionsAndAnswers(topic, 1);

            btn_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String UserAnswer = p1Answer.getText().toString();
                    currentQuestionIndex--;
                    if (UserAnswer.toLowerCase().equals(answers.get(currentQuestionIndex).toLowerCase())){
                        singleScore++;
                    }
                    currentQuestionIndex++;
                    displayNextQuestion2();
                    p1Answer.setText("");
                }
            });


        }

        else if (numberOfPlayers>=2){
            currentQuestionIndex=0;
            p1Answer.setVisibility(View.INVISIBLE);
            btn_submit.setVisibility(View.INVISIBLE);
            playerScores = new int[numberOfPlayers];

            fetchQuestionsAndAnswers(topic, 2);

            if (numberOfPlayers < 3) {
                player3Button.setVisibility(Button.GONE);
            } else {
                player3Button.setVisibility(Button.VISIBLE);
            }

            if (numberOfPlayers < 4) {
                player4Button.setVisibility(Button.GONE);
            } else {
                player3Button.setVisibility(Button.VISIBLE);
                player4Button.setVisibility(Button.VISIBLE);
            }

            player1Button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handlePlayerAnswer(1);
                }
            });
            player2Button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handlePlayerAnswer(2);
                }
            });
            if (numberOfPlayers == 3){
                player3Button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        handlePlayerAnswer(3);
                    }
                });
            }
            else if (numberOfPlayers == 4){
                player3Button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        handlePlayerAnswer(3);
                    }
                });
                player4Button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        handlePlayerAnswer(4);
                    }
                });
            }

        }
        btnsubmit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder adb=new AlertDialog.Builder(GameActivity.this);
                adb.setIcon(R.drawable.quizwhiz2);
                adb.setTitle("Confirm");
                adb.setMessage("Are you sure you want to exit?");
                adb.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent j= new Intent(GameActivity.this, MainActivity.class);
                        currentQuestionIndex=Integer.MAX_VALUE;
                        timer.cancel();
                        deleteUserFromDb();
                        startActivity(j);
                    }
                });
                adb.setNegativeButton("Canel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                Dialog d=adb.create();
                d.show();
            }
        });

    }

    public void handlePlayerAnswer(int player) {
        if (n!=1){
            playerScores[player - 1] += 10;
            updateScores(numberOfPlayers);
            n = displayNextQuestion();
        }
    }


    public void updateScores(int n) {
        player1Button.setText("Player 1 : "+playerScores[0]);
        player2Button.setText("Player 2 : "+playerScores[1]);
        if (n==3){
            player3Button.setText("Player 3 : "+playerScores[2]);
        }
        else if (n==4){
            player3Button.setText("Player 3 : "+playerScores[2]);
            player4Button.setText("Player 4 : "+playerScores[3]);
        }
    }

    public void startTimer() {
        timer = new CountDownTimer(20000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerTextView.setText("Time: " + millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                timerTextView.setText("Time's up!");
                displayNextQuestion();
            }
        };
        timer.start();
    }

    public void startTimer2() {
        timer = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerTextView.setText("Time: " + millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                timerTextView.setText("Time's up!");
                currentQuestionIndex=Integer.MAX_VALUE;
                displayNextQuestion2();
            }
        };
        timer.start();
    }

    public int displayNextQuestion() {
        if (timer != null) {
            timer.cancel();
        }

        if (currentQuestionIndex < 10) {
            questionTextView.setText((currentQuestionIndex+1)+". "+questions.get(currentQuestionIndex));
            Winner.setText("Answer: "+answers.get(currentQuestionIndex));
            Winner.setTextColor(Color.GREEN);
            currentQuestionIndex++;
            startTimer();
            return 0;
        } else {
            Winner.setVisibility(View.INVISIBLE);
            btnsubmit2.setVisibility(View.INVISIBLE);
            questionTextView.setText("Game Over!");
            String scores = "Final Scores: \n";
            for (int i = 0; i < playerScores.length; i++) {
                scores += "Player " + (i + 1) + ": " + playerScores[i] + "\n";
            }
            scoreTextView.setText(scores);

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(GameActivity.this, MainActivity.class);
                    startActivity(i);
                }
            }, 5000);

            return 1;
        }
    }

    public void displayNextQuestion2() {

        if (currentQuestionIndex < 39) {
            questionTextView.setText((currentQuestionIndex+1)+". "+questions.get(currentQuestionIndex));
            currentQuestionIndex++;
        } else {
            btnsubmit2.setVisibility(View.INVISIBLE);
            p1Answer.setVisibility(View.INVISIBLE);
            btn_submit.setVisibility(View.INVISIBLE);
            questionTextView.setText("Game Over!");
            Winner.setText("Final Score:\n"+singleScore+"/40");
            if (singleScore<20){
                Winner.setTextColor(Color.RED);
            }
            else if (singleScore<30 && singleScore>20){
                Winner.setTextColor(Color.YELLOW);
            }
            else {
                Winner.setTextColor(Color.GREEN);
            }
            if (timer!=null){
                timer.cancel();
            }
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(GameActivity.this, MainActivity.class);
                    startActivity(i);
                }
            }, 5000);
            updateLeaderboard(PlayerName, singleScore);
        }
    }
    public void updateLeaderboard(String playerName, int score) {
        SharedPreferences preferences = getSharedPreferences("QuizWhiz", MODE_PRIVATE);
        SharedPreferences.Editor ed = preferences.edit();

        String currentBoard = preferences.getString("leaderboard", "");

        String New = playerName + ":" + score;
        String updatedLeaderboard = currentBoard.isEmpty() ? New : currentBoard + ";" + New;

        ed.putString("leaderboard", updatedLeaderboard);
        ed.apply();
    }
    public void deleteUserFromDb() {
        String url = "http://10.0.2.2/QUIZWHIZPHP/DeleteUser.php";
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if ("1".equals(response)) {
                            Toast.makeText(getApplicationContext(), "Last user deleted successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Error deleting user", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });

        queue.add(stringRequest);
    }

    public void fetchQuestionsAndAnswers(String topic, int n) {
        String questionsUrl = "http://10.0.2.2/QUIZWHIZPHP/RetrieveQuestion.php?topic=" + topic;

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest questionRequest = new JsonArrayRequest(Request.Method.GET, questionsUrl, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            questions.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject questionObject = response.getJSONObject(i);
                                String question = questionObject.getString("question");
                                questions.add(question);
                            }

                            fetchAnswers(topic, n);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(GameActivity.this, "Error parsing questions", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(GameActivity.this, "Error fetching questions", Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(questionRequest);
    }

    private void fetchAnswers(String topic, int n) {
        String answersUrl = "http://10.0.2.2/QUIZWHIZPHP/RetrieveAnswer.php?topic=" + topic;

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest answerRequest = new JsonArrayRequest(Request.Method.GET, answersUrl, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            answers.clear();
                            for (int i = 0; i < response.length(); i++) {
                                answers.add(response.getString(i));
                            }

                            if (questions.size() > 0 && answers.size() > 0) {
                                if (n==1){
                                    startTimer2();
                                    displayNextQuestion2();
                                }
                                if(n==2){
                                    displayNextQuestion();
                                }
                            } else {
                                Toast.makeText(GameActivity.this, "No data available", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(GameActivity.this, "Error answers", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(GameActivity.this, "Error fetching answers", Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(answerRequest);
    }



}
package com.example.trivia;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class LeaderboardActivity extends AppCompatActivity {

    TextView leaderboardTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        leaderboardTextView = findViewById(R.id.leaderboard_text);

        SharedPreferences preferences = getSharedPreferences("QuizWhiz", MODE_PRIVATE);
        String leaderboardData = preferences.getString("leaderboard", "");

        leaderboardTextView.setText(NewLead(leaderboardData));
    }

    public String NewLead(String data) {
        if (data.isEmpty()) {
            return "No scores yet!";
        }

        List<ScoreEntry> scoreList = new ArrayList<>();
        int start = 0;
        for (int i = 0; i < data.length(); i++) {
            if (data.charAt(i) == ';') {
                String en = data.substring(start, i);
                scoreList.add(ScoreP(en));
                start = i + 1;
            }
        }
        if (start < data.length()) {
            scoreList.add(ScoreP(data.substring(start)));
        }

        for (int i = 0; i < scoreList.size(); i++) {
            for (int j = i + 1; j < scoreList.size(); j++) {
                if (scoreList.get(i).score < scoreList.get(j).score) {
                    ScoreEntry temp = scoreList.get(i);
                    scoreList.set(i, scoreList.get(j));
                    scoreList.set(j, temp);
                }
            }
        }

        String result = "";
        int rank = 1;
        for (ScoreEntry entry : scoreList) {
            result += rank + ". " + entry.name + " - " + entry.score + "\n";
            rank++;
        }

        return result;
    }

        public ScoreEntry ScoreP(String entry) {
        int Index = entry.indexOf(':');
        if (Index == -1) {
            return new ScoreEntry("Unknown", 0);
        }
        String name = entry.substring(0, Index);
        int score = Integer.parseInt(entry.substring(Index + 1));
        return new ScoreEntry(name, score);
    }

    public static class ScoreEntry {
        String name;
        int score;

        ScoreEntry(String name, int score) {
            this.name = name;
            this.score = score;
        }
    }
}

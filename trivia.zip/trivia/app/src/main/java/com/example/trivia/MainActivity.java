package com.example.trivia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button LocalMultiplayerBTN, SinglePlayerBTN, Leaderboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LocalMultiplayerBTN = findViewById(R.id.btn_multiplayer);
        SinglePlayerBTN = findViewById(R.id.btn_Single_Player);
        Leaderboard = findViewById(R.id.Leader);

        LocalMultiplayerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, TopicSelectionActivity.class);
                i.putExtra("LocalOrSingle", 1);
                startActivity(i);
            }
        });
        SinglePlayerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, TopicSelectionActivity.class);
                i.putExtra("LocalOrSingle", 2);
                startActivity(i);
            }
        });
        Leaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, LeaderboardActivity.class);
                startActivity(i);
            }
        });
    }
}
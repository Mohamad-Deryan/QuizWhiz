package com.example.trivia;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

public class TopicSelectionActivity extends AppCompatActivity {

    String selectedTopic = "Math";
    EditText PlayerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic_selection);

        TextView txt;
        RadioButton Ma, Sc, Ge, Sp, Mo, Mu, An, Mi;
        Ma = findViewById(R.id.radio_math);
        Sc = findViewById(R.id.radio_science);
        Ge = findViewById(R.id.radio_geography);
        Sp = findViewById(R.id.radio_sports);
        Mo = findViewById(R.id.radio_movies);
        Mu = findViewById(R.id.radio_music);
        An = findViewById(R.id.radio_animals);
        Mi = findViewById(R.id.radio_mix);
        PlayerName = findViewById(R.id.PlayerName);

        Intent i = getIntent();
        int localOrSingle = i.getIntExtra("LocalOrSingle", 1);


        if (localOrSingle==1){
            PlayerName.setVisibility(View.INVISIBLE);
            Spinner playersSpinner = findViewById(R.id.spinner_players);
            Button startGameButton = findViewById(R.id.btn_multiplayer);
            startGameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(TopicSelectionActivity.this, GameActivity.class);
                    int numbPlayers = Integer.parseInt(playersSpinner.getSelectedItem().toString());
                        if (Ma.isChecked()) {
                            selectedTopic = "Math";
                        } else if (Sc.isChecked()) {
                            selectedTopic = "Science";
                        } else if (Ge.isChecked()) {
                            selectedTopic = "Geography";
                        } else if (Sp.isChecked()) {
                            selectedTopic = "Sports";
                        } else if (Mo.isChecked()) {
                            selectedTopic = "Movies";
                        } else if (Mu.isChecked()) {
                            selectedTopic = "Music";
                        } else if (An.isChecked()) {
                            selectedTopic = "Animals";
                        } else if (Mi.isChecked()) {
                            selectedTopic = "Mix";
                        }
                        intent.putExtra("selectedTopic", selectedTopic);
                        intent.putExtra("selectedPlayers", numbPlayers);
                        startActivity(intent);
                    }
            });
        }

        else if (localOrSingle==2){
            Spinner playersSpinner = findViewById(R.id.spinner_players);
            playersSpinner.setVisibility(View.INVISIBLE);
            txt = findViewById(R.id.text_choose_players);
            txt.setVisibility(View.INVISIBLE);

            Button startGameButton = findViewById(R.id.btn_multiplayer);
            startGameButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String name = PlayerName.getText().toString();
                    if (TextUtils.isEmpty(name)){
                        PlayerName.setError("Oh no! Name is missing!");
                    }
                    else {
                        addUserToDb(name);
                        Intent intent = new Intent(TopicSelectionActivity.this, GameActivity.class);
                        if(Ma.isChecked()){
                            selectedTopic = "Math";
                        }
                        else if (Sc.isChecked()){
                            selectedTopic = "Science";
                        }
                        else if (Ge.isChecked()){
                            selectedTopic = "Geography";
                        }
                        else if (Sp.isChecked()){
                            selectedTopic = "Sports";
                        }
                        else if (Mo.isChecked()){
                            selectedTopic = "Movies";
                        }
                        else if (Mu.isChecked()){
                            selectedTopic = "Music";
                        }
                        else if (An.isChecked()){
                            selectedTopic = "Animals";
                        }
                        else if (Mi.isChecked()){
                            selectedTopic = "Mix";
                        }
                        intent.putExtra("PlayerName", name);
                        intent.putExtra("selectedTopic", selectedTopic);
                        intent.putExtra("selectedPlayers", 1);
                        startActivity(intent);
                    }
                }
            });
        }
    }

    public void addUserToDb(String name) {
        String url = "http://10.0.2.2/QUIZWHIZPHP/AddUser.php?name="+name;

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if ("1".equals(response)) {
                            Toast.makeText(getApplicationContext(), "User added successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Error adding user", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(stringRequest);
    }

}